import numbers
import random
from random import randint

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
import time

#driver = webdriver.Chrome(executable_path= 'F:\chromedriver\chromedriver.exe')
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
driver.implicitly_wait(30)

#driver.get("http://selenium.dev")
driver.get("http://159.89.38.11/login")
#driver.implicitly_wait(15)

driver.maximize_window()

def login():
    driver.find_element(By.ID, 'email-1').send_keys("test@orangetoolz.com")
    # driver.implicitly_wait(100)
    time.sleep(1)

    driver.find_element(By.ID, 'password-1').send_keys("8Kh8nTe*^jdk")
    # driver.implicitly_wait(100)
    time.sleep(1)

    driver.find_element(By.ID, 'checkbox-1').click()
    time.sleep(1)

    driver.find_element(By.ID, 'm_login_signin_submit').click()
    time.sleep(5)
    print("Login initialized!!")

login()

def contactManage():
    #go to sidebar
    driver.find_element(By.ID, 'main-sidebar').click()
    time.sleep(2)

    #select contact manage
    driver.find_element(By.XPATH, "//span[normalize-space()='Contact Manage']").click()

    print('contact manage initialized!!')

contactManage()

def addContact():
    # add to contacts
    driver.find_element(By.XPATH, "//a[normalize-space()='Add Contact']").click()
    time.sleep(1)
    print("clicked on +add contact")


addContact()

def createContact():
    #Number
    driver.find_element(By.XPATH, "//input[@placeholder='Enter Number']").send_keys(randint(1000000000,5000000000))
    #Email
    driver.find_element(By.XPATH, "//input[@placeholder='Enter Email address']").send_keys("Maynul@xyz.com")
    #FirstName
    driver.find_element(By.XPATH, "//input[@placeholder='Enter First name']").send_keys("Maynul")
    #LastName
    driver.find_element(By.XPATH, "//input[@placeholder='Enter Last name']").send_keys("Islam")
    #Birthday
    driver.find_element(By.XPATH, "//input[@placeholder='Enter your birthday']").send_keys("2013-11-04")
    #(Address),City
    driver.find_element(By.XPATH, "//input[@placeholder='Enter your city']").send_keys("dsfsfgsf")
    #State
    driver.find_element(By.XPATH, "//input[@placeholder='Enter your state']").send_keys("sdfdssd")
    #Zip
    driver.find_element(By.XPATH, "//input[@placeholder='Enter your Zip']").send_keys("12635")
    #Country
    driver.find_element(By.XPATH, "//input[@placeholder='Enter your country']").send_keys("Bangladesh")
    #Address
    driver.find_element(By.XPATH, "//textarea[@placeholder='Enter your address']").send_keys("kosdonsjdnvjisib,ajiocndnnds")

    #click on Add Contact
    driver.find_element(By.XPATH, "//button[normalize-space()='Add Contact']").click()

    print("Contact added successfully!!")
    time.sleep(4)

createContact()

i = 1
while i <= 5:
    addContact()
    time.sleep(2)
    createContact()
    i = i+1
    print("adding contact", i)


driver.close()
driver.quit()
