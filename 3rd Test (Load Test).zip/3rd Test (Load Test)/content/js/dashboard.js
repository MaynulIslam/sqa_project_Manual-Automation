/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 98.95953757225433, "KoPercent": 1.0404624277456647};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.5340782122905028, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.4666666666666667, 500, 1500, "http://159.89.38.11/login-9"], "isController": false}, {"data": [0.0, 500, 1500, "http://159.89.38.11/login"], "isController": false}, {"data": [0.0, 500, 1500, "http://159.89.38.11/login-8"], "isController": false}, {"data": [0.7666666666666667, 500, 1500, "http://159.89.38.11/login-5"], "isController": false}, {"data": [0.5, 500, 1500, "http://159.89.38.11/login-4"], "isController": false}, {"data": [0.9, 500, 1500, "http://159.89.38.11/login-7"], "isController": false}, {"data": [0.9833333333333333, 500, 1500, "http://159.89.38.11/login-6"], "isController": false}, {"data": [0.8068181818181818, 500, 1500, "http://159.89.38.11/login-1"], "isController": false}, {"data": [0.3352272727272727, 500, 1500, "http://159.89.38.11/login-0"], "isController": false}, {"data": [0.45, 500, 1500, "http://159.89.38.11/login-19"], "isController": false}, {"data": [0.4, 500, 1500, "http://159.89.38.11/login-3"], "isController": false}, {"data": [0.711864406779661, 500, 1500, "http://159.89.38.11/login-2"], "isController": false}, {"data": [0.65, 500, 1500, "http://159.89.38.11/login-16"], "isController": false}, {"data": [0.7, 500, 1500, "http://159.89.38.11/login-15"], "isController": false}, {"data": [0.6833333333333333, 500, 1500, "http://159.89.38.11/login-18"], "isController": false}, {"data": [0.31666666666666665, 500, 1500, "http://159.89.38.11/login-17"], "isController": false}, {"data": [0.48333333333333334, 500, 1500, "http://159.89.38.11/login-12"], "isController": false}, {"data": [0.21666666666666667, 500, 1500, "http://159.89.38.11/login-11"], "isController": false}, {"data": [0.3, 500, 1500, "http://159.89.38.11/login-14"], "isController": false}, {"data": [0.05, 500, 1500, "http://159.89.38.11/login-13"], "isController": false}, {"data": [1.0, 500, 1500, "http://159.89.38.11/login/submit"], "isController": false}, {"data": [0.0, 500, 1500, "Test"], "isController": true}, {"data": [0.48333333333333334, 500, 1500, "http://159.89.38.11/login-10"], "isController": false}, {"data": [0.9, 500, 1500, "http://159.89.38.11/login-21"], "isController": false}, {"data": [0.9333333333333333, 500, 1500, "http://159.89.38.11/login-20"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 865, 9, 1.0404624277456647, 1358.6104046242772, 118, 10411, 750.0, 3786.399999999997, 5967.599999999995, 8458.480000000003, 13.494539781591264, 1516.937752900741, 20.19412417121685], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["http://159.89.38.11/login-9", 30, 1, 3.3333333333333335, 1046.1666666666665, 685, 1686, 1039.0, 1102.5, 1408.7999999999997, 1686.0, 0.5120152921900601, 25.359790745750274, 0.8543755173487848], "isController": false}, {"data": ["http://159.89.38.11/login", 30, 2, 6.666666666666667, 6937.466666666667, 4256, 10411, 6761.0, 9177.7, 9968.8, 10411.0, 0.47066944884607537, 635.246881447191, 9.117550552840491], "isController": false}, {"data": ["http://159.89.38.11/login-8", 30, 1, 3.3333333333333335, 5900.8, 2873, 9598, 5792.0, 8336.700000000003, 9015.55, 9598.0, 0.47933276878585007, 235.62686677644717, 0.8390351880182785], "isController": false}, {"data": ["http://159.89.38.11/login-5", 30, 0, 0.0, 427.56666666666666, 224, 921, 331.0, 772.6000000000004, 885.8, 921.0, 0.5172057099510378, 61.56057798815599, 0.20809448486311288], "isController": false}, {"data": ["http://159.89.38.11/login-4", 30, 0, 0.0, 635.1333333333336, 299, 1782, 577.0, 635.5, 1762.75, 1782.0, 0.5147740142077627, 1.43272064501184, 0.47747300653763], "isController": false}, {"data": ["http://159.89.38.11/login-7", 30, 0, 0.0, 404.66666666666663, 159, 1178, 330.5, 981.4000000000007, 1171.95, 1178.0, 0.5190131829348466, 12.0994103523667, 0.2108491055672814], "isController": false}, {"data": ["http://159.89.38.11/login-6", 30, 0, 0.0, 171.39999999999998, 118, 1130, 127.5, 225.70000000000005, 636.6499999999994, 1130.0, 0.5181436639665625, 8.166345570519352, 0.20897786447088895], "isController": false}, {"data": ["http://159.89.38.11/login-1", 88, 0, 0.0, 467.46590909090924, 218, 2113, 274.5, 823.3000000000021, 1629.1499999999999, 2113.0, 1.3953635873529318, 10.573852566160847, 1.0400655414565694], "isController": false}, {"data": ["http://159.89.38.11/login-0", 88, 0, 0.0, 2263.465909090909, 505, 8795, 779.0, 5926.8, 6973.4, 8795.0, 1.3863507467389249, 245.5835300940513, 0.9917626346965782], "isController": false}, {"data": ["http://159.89.38.11/login-19", 30, 1, 3.3333333333333335, 946.4666666666667, 256, 2342, 808.0, 1649.8000000000004, 2013.0999999999995, 2342.0, 0.5147916809664356, 24.179808824601892, 0.44943726834374353], "isController": false}, {"data": ["http://159.89.38.11/login-3", 30, 0, 0.0, 1109.8666666666666, 525, 2465, 824.0, 2264.5000000000005, 2364.35, 2465.0, 0.5119890775663453, 8.275823449099752, 0.4613901570099838], "isController": false}, {"data": ["http://159.89.38.11/login-2", 59, 0, 0.0, 680.3220338983053, 198, 2868, 498.0, 1166.0, 1873.0, 2868.0, 0.9987642408545359, 23.123435463325038, 0.6650768699321179], "isController": false}, {"data": ["http://159.89.38.11/login-16", 30, 0, 0.0, 746.3, 250, 2454, 508.5, 2198.1000000000013, 2447.4, 2454.0, 0.5206886975840044, 12.39228930548806, 0.48092516618647596], "isController": false}, {"data": ["http://159.89.38.11/login-15", 30, 0, 0.0, 527.8666666666668, 248, 1178, 517.5, 922.1000000000003, 1086.1499999999999, 1178.0, 0.5174287241932424, 9.377890324514048, 0.48195655970265094], "isController": false}, {"data": ["http://159.89.38.11/login-18", 30, 0, 0.0, 699.6999999999999, 254, 2861, 516.5, 2069.3000000000015, 2496.8999999999996, 2861.0, 0.5184929139301763, 10.291375464483236, 0.46370684626685105], "isController": false}, {"data": ["http://159.89.38.11/login-17", 30, 1, 3.3333333333333335, 1406.6999999999998, 512, 3156, 1280.5, 2217.7000000000007, 3013.0, 3156.0, 0.5138482092389909, 40.98956459928404, 0.4549195881078396], "isController": false}, {"data": ["http://159.89.38.11/login-12", 30, 0, 0.0, 1192.5666666666666, 261, 1693, 1249.0, 1482.9, 1595.6499999999999, 1693.0, 0.5099959200326397, 21.993574051407588, 0.45710376504487965], "isController": false}, {"data": ["http://159.89.38.11/login-11", 30, 1, 3.3333333333333335, 1604.7333333333331, 401, 2446, 1603.0, 2141.4, 2329.3999999999996, 2446.0, 0.5058851303497353, 42.26174588862939, 0.44490555230009105], "isController": false}, {"data": ["http://159.89.38.11/login-14", 30, 1, 3.3333333333333335, 1327.6666666666667, 494, 2316, 1400.0, 2016.1000000000001, 2223.0499999999997, 2316.0, 0.5044984444631295, 37.611015933742536, 0.45140458147649876], "isController": false}, {"data": ["http://159.89.38.11/login-13", 30, 1, 3.3333333333333335, 2500.6666666666665, 1007, 4594, 2603.5, 3936.1000000000004, 4269.5, 4594.0, 0.49585137681398955, 70.81103078204026, 0.43196531726223925], "isController": false}, {"data": ["http://159.89.38.11/login/submit", 30, 0, 0.0, 378.23333333333335, 352, 443, 372.0, 406.9, 433.09999999999997, 443.0, 0.5256794406770752, 0.46530844241181724, 0.518389745308311], "isController": false}, {"data": ["Test", 30, 2, 6.666666666666667, 7315.733333333333, 4660, 10804, 7130.5, 9545.1, 10339.8, 10804.0, 0.467428055031863, 631.2858270214316, 9.515706191279351], "isController": true}, {"data": ["http://159.89.38.11/login-10", 30, 0, 0.0, 1144.2, 763, 1584, 1054.0, 1417.9, 1520.75, 1584.0, 0.5140683368175742, 21.259035018763495, 0.46276190710785153], "isController": false}, {"data": ["http://159.89.38.11/login-21", 30, 0, 0.0, 368.1333333333334, 246, 1182, 266.5, 701.1000000000004, 984.5499999999997, 1182.0, 0.5213039549593382, 3.6664366050948773, 0.4646936036004726], "isController": false}, {"data": ["http://159.89.38.11/login-20", 30, 0, 0.0, 348.26666666666665, 246, 1033, 269.5, 822.4000000000005, 958.7499999999999, 1033.0, 0.5223477791513589, 2.185801009437083, 0.4676644960214511], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 7, 77.77777777777777, 0.8092485549132948], "isController": false}, {"data": ["Assertion failed", 2, 22.22222222222222, 0.23121387283236994], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 865, 9, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 7, "Assertion failed", 2, "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["http://159.89.38.11/login-9", 30, 1, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["http://159.89.38.11/login", 30, 2, "Assertion failed", 2, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["http://159.89.38.11/login-8", 30, 1, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["http://159.89.38.11/login-19", 30, 1, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["http://159.89.38.11/login-17", 30, 1, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["http://159.89.38.11/login-11", 30, 1, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["http://159.89.38.11/login-14", 30, 1, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["http://159.89.38.11/login-13", 30, 1, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
